package com.mycontacts;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "Contacts")
public class Contact {

	private String ContactName;
	private String ContactNumber;
	
	public Contact() {
		
	}

	public Contact(String ContactName, String ContactNumber) {
		this.ContactName = ContactName;
		this.ContactNumber = ContactNumber;
	}

	public String getContactName() {
		return ContactName;
	}
	@XmlElement
	public void setContactName(String ContactName) {
		this.ContactName = ContactName;
	}

	public String getContactNumber() {
		return ContactNumber;
	}
	@XmlElement
	public void setContactNumber(String ContactNumber) {
		this.ContactNumber = ContactNumber;
	}
	 
}
