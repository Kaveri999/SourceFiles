import { Injectable } from '@angular/core';
import { HttpClient,HttpParams } from '@angular/common/http';
import { Contact } from './contact';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ContactsService {
  conn: Contact = new Contact();
  constructor(private http: HttpClient) { }
  findDepartment(contactName: String): Observable<Contact> 
  {
    console.log(contactName)
    let url =  'http://localhost:8080/Phonebook/rest/Contacts/';
    console.log(url+contactName)
    return this.http.get<Contact>(url + contactName);
  }
  getContacts() {
    let url = 'http://localhost:8080/Phonebook/rest/Contacts';
    return this.http.get(url);
  }
  addContact(contact: Contact){
    let url = 'http://localhost:8080/Phonebook/rest/Contacts';
    return this.http.post(url,contact);
  }
  deleteContacts(contactName: String) 
  {
    console.log(contactName);
    console.log(contactName+" deleted success");
  
    let url = 'http://localhost:8080/Phonebook/rest/Contacts/';
    console.log(url+contactName);
     return this.http.delete(url+contactName);                
  }
  updateContact(contact: Contact){
    let url = 'http://localhost:8080/Phonebook/rest/Contacts';
    return this.http.put(url,contact);
  }

}
