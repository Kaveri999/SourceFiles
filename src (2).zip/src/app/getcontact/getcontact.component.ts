import { Component, OnInit } from '@angular/core';
import { Contact } from '../contact';
import { ContactsService } from '../contacts.service';

@Component({
  selector: 'app-getcontact',
  templateUrl: './getcontact.component.html',
  styleUrls: ['./getcontact.component.css']
})
export class GetcontactComponent implements OnInit {
  conn: Contact = new Contact();
  constructor(private service: ContactsService){
   
  }
  

  ngOnInit(): void {
  }
  getContact(){
    console.log(this.conn.contactName);
    this.service.findDepartment(this.conn.contactName)
    .subscribe((data: Contact) => {
        this.conn = data;
     
    });
    
  }
}
